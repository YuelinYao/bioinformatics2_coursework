var x, y;
var z_offset = 2; 
function mouseMove(e) {
    x = event.x + z_offset + document.body.scrollLeft;
    y = event.y + z_offset + document.body.scrollTop;
}

function showInput(str1)
{
	window.open(str1,'','');
}

function showTSS(str1,str2,str3,str4)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;Start:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;End:&nbsp;" + str2+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Score:&nbsp;" + str3+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Strand:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
    str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"TSS.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    TSS.innerHTML = str;
	TSS.style.top = parseInt(y);
    TSS.style.left = parseInt(x);
    TSS.style.visibility = 'visible';
}

function showTSS_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'TSS','menubar=no,status=no,scrollbars=yes,left=550,top=500,height=200,width=660');
}

function showCpG(str1,str2,str3,str4,str5,str6)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;Begin:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;End:&nbsp;" + str2+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;G+C frequency:&nbsp;" + str3+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;o/e ratio:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;AT skew:&nbsp;" + str5+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;GC skew:&nbsp;" + str6+ "&nbsp;</font></td></tr>";
    str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"CpG.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    CpG.innerHTML = str;
	CpG.style.top = parseInt(y);
    CpG.style.left = parseInt(x);
    CpG.style.visibility = 'visible';
}

function showCpG_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'CpG','menubar=no,status=no,scrollbars=yes,left=550,top=500,height=200,width=660');
}

function showTFBS(str1,str2,str3,str4,str5,str6,str7)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;Matrix:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Location:&nbsp;" + str2 + " ~ " + str3 + "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Strand:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;core score:&nbsp;" + str5+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;matrix score:&nbsp;" + str6+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Sequence:&nbsp;" + str7+ "&nbsp;</font></td></tr>";
    str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"TFBS.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    TFBS.innerHTML = str;
	TFBS.style.top = parseInt(y);
    TFBS.style.left = parseInt(x);
    TFBS.style.visibility = 'visible';
}

function showTFBS_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'TFBS','menubar=no,status=no,scrollbars=yes,left=550,top=500,height=200,width=660');
}

function showTATA(str1,str2,str3,str4)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;Type:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Location:&nbsp;" + str2+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Strand:&nbsp;" + str3+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Sequence:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
	str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"TATA.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    TATA.innerHTML = str;
	TATA.style.top = parseInt(y);
    TATA.style.left = parseInt(x);
    TATA.style.visibility = 'visible';
}

function showTATA_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'','menubar=no,status=no,scrollbars=yes,left=550,top=500,height=200,width=660');
}

function showOR(str1,str2,str3,str4,str5)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;OR Oligonucleotide:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Occurence:&nbsp;" + str2+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Observed Probability:&nbsp;" + str3+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Background Probability:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Z-score:&nbsp;" + str5+ "&nbsp;</font></td></tr>";
	str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"OR.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    OR.innerHTML = str;
	OR.style.top = parseInt(y);
    OR.style.left = parseInt(x);
    OR.style.visibility = 'visible';
}

function showOR2(str1,str2,str3,str4,str5,str6)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;OR Oligonucleotide:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Location:&nbsp;" + str2+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Strand:&nbsp;" + str3+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Observed Probability:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Background Probability:&nbsp;" + str5+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Z-score:&nbsp;" + str6+ "&nbsp;</font></td></tr>";
	str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"OR.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    OR.innerHTML = str;
	OR.style.top = parseInt(y);
    OR.style.left = parseInt(x);
    OR.style.visibility = 'visible';
}

function showOR_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'','menubar=no,status=no,scrollbars=yes,left=350,height=800');
}

function showTRF(str1,str2,str3,str4,str5,str6)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;Location:&nbsp;" + str1+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Period Size:&nbsp;" + str2 + "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Copy Number:&nbsp;" + str3+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Percent Matches:&nbsp;" + str4+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Score:&nbsp;" + str5+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Repeat Seed:<br>&nbsp;" + str6+ "&nbsp;</font></td></tr>";
    str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"TRF.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    TRF.innerHTML = str;
	TRF.style.top = parseInt(y);
    TRF.style.left = parseInt(x);
    TRF.style.visibility = 'visible';
}

function showTRF_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'','menubar=no,status=no,scrollbars=yes,left=550,top=500,height=200,width=660');
}

function showEnergy(str1)
{
	window.open(str1,'','menubar=no,status=no,scrollbars=yes,left=550,top=500,height=200');
}

function show_miRT(str1,str2,str3,str4,str5,str6,str7,str8)
{
	str = "";
	str += "<table border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td class=test2><font color=green>&nbsp;miRNA ID:&nbsp;<a href='http://microrna.sanger.ac.uk/cgi-bin/sequences/query.pl?terms=" + str1+ "' target='_blank'>" + str1 + "</a>&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Location:&nbsp;" + str2 + "&nbsp;</font></td></tr>";
	str += "<tr><td class=test3><font color=green><br><pre>miRNA : 3'-" + str3+ "-5'<br>           "+str4+"<br>Target: 5'-"+str5+"-3'</pre></font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Score:&nbsp;" + str6+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Minimum Free Energy:&nbsp;" + str7+ "&nbsp;</font></td></tr>";
	str += "<tr><td class=test2><font color=green>&nbsp;Identity:&nbsp;" + str8+ "&nbsp;</font></td></tr>";
    str += "<tr align='right' class=test2><th bgcolor=#FFFFCC style='cursor:pointer' onClick=\"miRT.style.visibility = 'hidden';\"><font color=#840000>&nbsp;X&nbsp;</font></th></tr>";
    str += "</table>";
    miRT.innerHTML = str;
	miRT.style.top = parseInt(y);
    miRT.style.left = parseInt(x);
    miRT.style.visibility = 'visible';
}

function show_miRT_Table(str)
{
	strFeatures = "top=150,left=150,width=400,height=305,toolbar=0,menubar=0,location=0,directories=0,status=0";
	window.open(str,'','menubar=no,status=no,scrollbars=yes,left=550,top=500');
}

function HomologsSearch(str1,str2)
{
	str = "<form action=http://GPMiner.mbc.nctu.edu.tw/sequence_search.php method=post target='_blank'>";
	str += "<input type=hidden name='species' value='" + str1 + "'>";
	str += "<input type=hidden name='file' value='" + str2 + "'>";
	str += "<input type=hidden name='query_type' value='sequence'>";
	str += "<table width=300 border=0 cellpadding=0 cellspacing=0 class=test1>";
	str += "<tr><td colspan=2 class=test2 bgcolor=#FFFFCC><font color=red>Sequence Homologous to Known Gene Promoters</font></td></tr>";
	str += "<tr><td class=test2 align=center>Species</td><td align=left class=test2><select name='species' class='style1'><option value='human' selected>Human</option><option value='mouse'>Mouse</option><option value='rat'>Rat</option><option value='dog'>Dog</option><option value='chimp'>Chimpanzee</option></select></td></tr>";
	str += "<tr><td class=test2 align=center>Promoter Region</td><td align=left class=test2><select name='promoter_range' class='style1'><option value='-1000 ~ first exon end'>-1000 ~ first exon end</option><option value='-2000 ~ first exon end' selected>-2000 ~ first exon end</option><option value='-3000 ~ first exon end'>-3000 ~ first exon end</option></select></td></tr>";
	str += "<tr><td class=test2 align=center>Blast E-value</td><td align=left class=test2><input name='E_value' type='text' value='1e-10' size='5' class='style1'></td></tr>";
	str += "<tr><td class=test2 align=center>&nbsp;</td><td align=right class=test2><input type=submit value='Blast' class='style1'><input type=button value='Close' class='style1' onClick=\"Homologs.style.visibility = 'hidden';\"></td></tr>";
    str += "</table>";
	str += "</form>";

	Homologs.innerHTML = str;
	Homologs.style.top = parseInt(y);
    Homologs.style.left = parseInt(x);
	Homologs.style.visibility = 'visible';
}

document.onmousemove = mouseMove;